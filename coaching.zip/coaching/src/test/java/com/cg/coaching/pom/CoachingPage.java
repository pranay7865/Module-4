package com.cg.coaching.pom;

public class CoachingPage {

}
