package com.cg.coaching.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class CoachingPage {
	WebDriver driver;

	@FindBy(how = How.NAME, using = "fname")
	@CacheLookup
	private WebElement fname;

	@FindBy(how = How.NAME, using = "lname")
	@CacheLookup
	private WebElement lname;

	@FindBy(how = How.NAME, using = "email")
	@CacheLookup
	private WebElement email;

	@FindBy(how = How.NAME, using = "mobile")
	@CacheLookup
	private WebElement mobile;

	@FindBy(how = How.NAME, using = "learningMode")
	@CacheLookup
	private WebElement learningMode;

	@FindBy(how = How.NAME, using = "city")
	@CacheLookup
	private WebElement city;

	@FindBy(how = How.NAME, using = "request")
	@CacheLookup
	private WebElement request;

	public WebElement getRequest() {
		return request;
	}

	public void setRequest() {
		this.request.click();
	}

	public WebElement getReset() {
		return reset;
	}

	public void setReset() {
		this.reset.click();
	}

	@FindBy(how = How.NAME, using = "text")
	@CacheLookup
	private WebElement text;

	public String getText() {
		return text.getText();
	}

	public void setText(WebElement text) {
		this.text = text;
	}

	@FindBy(how = How.NAME, using = "reset")
	@CacheLookup
	private WebElement reset;

	@FindBy(how = How.NAME, using = "tuitiontype")
	@CacheLookup
	private WebElement tuitiontype;

	@FindBy(how = How.NAME, using = "enquiry")
	@CacheLookup
	private WebElement enquiry;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public WebElement getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getLearningMode() {
		return learningMode;
	}

	public void setLearningMode(String learningMode) {
		// this.learningMode.sendKeys(learningMode);
		Select dropDown = new Select(this.learningMode);
		dropDown.selectByVisibleText(learningMode);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		// this.city.sendKeys(city);
		Select dropDown = new Select(this.city);
		dropDown.selectByVisibleText(city);
	}

	public WebElement getTuitiontype() {
		return tuitiontype;
	}

	public void setTuitiontype(String tuitiontype) {
		// this.tuitiontype.sendKeys(tuitiontype);
		Select dropDown = new Select(this.tuitiontype);
		dropDown.selectByVisibleText(tuitiontype);
	}

	public WebElement getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(String enquiry) {
		this.enquiry.sendKeys(enquiry);
	}

}
