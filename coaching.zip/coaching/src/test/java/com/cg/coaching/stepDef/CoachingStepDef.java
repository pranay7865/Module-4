package com.cg.coaching.stepDef;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.coaching.pom.CoachingPage;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class CoachingStepDef {

	WebDriver driver;
	CoachingPage page;

	@Given("^user is on coaching enquiry form$")
	public void user_is_on_coaching_enquiry_form() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\pransont\\Desktop\\Module 4\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		Thread.sleep(5000);
		driver.get(
				"C:\\Users\\pransont\\Desktop\\Module 4\\Selenium Programs\\coaching\\src\\test\\java\\com\\cg\\coaching\\html\\Coaching_Class_Enquiry.html");
		page = PageFactory.initElements(driver, CoachingPage.class);
		driver.manage().window().maximize();
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() {
		System.out.println("Title of the page : " + driver.getTitle());
		assertEquals("Coaching_Class_Enquiry", driver.getTitle());
	}

	@Then("^check if text is present$")
	public void check_if_text_is_present() {
		System.out.println("Text on the page : " + page.getText());
		assertEquals("Tuition Enquiry Details Form", page.getText());
	}

	@Given("^fill form data except first name$")
	public void fill_form_data_except_first_name() throws InterruptedException {
		page.setFname("");
		Thread.sleep(500);
		page.setLname("Sontakke");
		Thread.sleep(500);
		page.setEmail("pranay@gmail.com");
		Thread.sleep(500);
		page.setMobile("7798432876");
		Thread.sleep(500);
		page.setTuitiontype("Soft Skills Development");
		Thread.sleep(500);
		page.setCity("Pune");
		Thread.sleep(500);
		page.setLearningMode("Online Training");
		Thread.sleep(500);
		page.setEnquiry("I want to know about how helpful can online training???");
		Thread.sleep(500);
	}

	@Given("^click on submit$")
	public void click_on_submit() throws InterruptedException {
		Thread.sleep(3000);
		page.setRequest();
	}

	@Then("^switch to alert and accept it$")
	public void switch_to_alert_and_accept_it() throws Throwable {
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}

	@Given("^fill form data except last name$")
	public void fill_form_data_except_last_name() throws InterruptedException {
		page.setFname("Pranay");
		Thread.sleep(500);
		page.setLname("");
		Thread.sleep(500);
		page.setEmail("pranay@gmail.com");
		Thread.sleep(500);
		page.setMobile("7798432876");
		Thread.sleep(500);
		page.setTuitiontype("Soft Skills Development");
		Thread.sleep(500);
		page.setCity("Pune");
		Thread.sleep(500);
		page.setLearningMode("Online Training");
		Thread.sleep(500);
		page.setEnquiry("I want to know about how helpful can online training???");
		Thread.sleep(500);
	}

	@Given("^fill form data except email empty$")
	public void fill_form_data_except_email_empty() throws InterruptedException {
		page.setFname("Pranay");
		Thread.sleep(500);
		page.setLname("Sontakke");
		Thread.sleep(500);
		page.setEmail("");
		Thread.sleep(500);
		page.setMobile("7798432876");
		Thread.sleep(500);
		page.setTuitiontype("Soft Skills Development");
		Thread.sleep(500);
		page.setCity("Pune");
		Thread.sleep(500);
		page.setLearningMode("Online Training");
		Thread.sleep(500);
		page.setEnquiry("I want to know about how helpful can online training???");
		Thread.sleep(500);
	}

	@Given("^fill form data except mobile$")
	public void fill_form_data_except_mobile() throws InterruptedException {
		page.setFname("Pranay");
		Thread.sleep(500);
		page.setLname("Sontakke");
		Thread.sleep(500);
		page.setEmail("pranay@gmail.com");
		Thread.sleep(500);
		page.setMobile("");
		Thread.sleep(500);
		page.setTuitiontype("Soft Skills Development");
		Thread.sleep(500);
		page.setCity("Pune");
		Thread.sleep(500);
		page.setLearningMode("Online Training");
		Thread.sleep(500);
		page.setEnquiry("I want to know about how helpful can online training???");
		Thread.sleep(500);
	}

	@Given("^fill form data except tuition type$")
	public void fill_form_data_except_tuition_type() throws InterruptedException {
		page.setFname("Pranay");
		Thread.sleep(500);
		page.setLname("Sontakke");
		Thread.sleep(500);
		page.setEmail("pranay@gmail.com");
		Thread.sleep(500);
		page.setMobile("7798432876");
		Thread.sleep(500);
		// page.setTuitiontype("");Thread.sleep(500);
		page.setCity("Pune");
		Thread.sleep(500);
		page.setLearningMode("Online Training");
		Thread.sleep(500);
		page.setEnquiry("I want to know about how helpful can online training???");
		Thread.sleep(500);
	}

	@Given("^fill form data except city$")
	public void fill_form_data_except_city() throws InterruptedException {
		page.setFname("Pranay");
		Thread.sleep(500);
		page.setLname("Sontakke");
		Thread.sleep(500);
		page.setEmail("pranay@gmail.com");
		Thread.sleep(500);
		page.setMobile("7798432876");
		Thread.sleep(500);
		page.setTuitiontype("Soft Skills Development");
		Thread.sleep(500);
		// page.setCity("");Thread.sleep(500);
		page.setLearningMode("Online Training");
		Thread.sleep(500);
		page.setEnquiry("I want to know about how helpful can online training???");
		Thread.sleep(500);
	}

	@Given("^fill form data except learning mode$")
	public void fill_form_data_except_learning_mode() throws InterruptedException {
		page.setFname("Pranay");
		Thread.sleep(500);
		page.setLname("Sontakke");
		Thread.sleep(500);
		page.setEmail("pranay@gmail.com");
		Thread.sleep(500);
		page.setMobile("7798432876");
		Thread.sleep(500);
		page.setTuitiontype("Soft Skills Development");
		Thread.sleep(500);
		page.setCity("Pune");
		Thread.sleep(500);
		// page.setLearningMode("");Thread.sleep(500);
		page.setEnquiry("I want to know about how helpful can online training???");
		Thread.sleep(500);
	}

	@Given("^fill form data except enquiry$")
	public void fill_form_data_except_enquiry() throws InterruptedException {
		page.setFname("Pranay");
		Thread.sleep(500);
		page.setLname("Sontakke");
		Thread.sleep(500);
		page.setEmail("pranay@gmail.com");
		Thread.sleep(500);
		page.setMobile("7798432876");
		Thread.sleep(500);
		page.setTuitiontype("Soft Skills Development");
		Thread.sleep(500);
		page.setCity("Pune");
		Thread.sleep(500);
		page.setLearningMode("Online Training");
		Thread.sleep(500);
		page.setEnquiry("");
		Thread.sleep(500);
	}
	
	@Given("^fill form data$")
	public void fill_form_data() throws Throwable {
		page.setFname("Pranay");
		Thread.sleep(500);
		page.setLname("Sontakke");
		Thread.sleep(500);
		page.setEmail("pranay@gmail.com");
		Thread.sleep(500);
		page.setMobile("7798432876");
		Thread.sleep(500);
		page.setTuitiontype("Soft Skills Development");
		Thread.sleep(500);
		page.setCity("Pune");
		Thread.sleep(500);
		page.setLearningMode("Online Training");
		Thread.sleep(500);
		page.setEnquiry("I want to know about how helpful can online training???");
		Thread.sleep(500);
	}
	
	@After
	public void closeDriver() throws InterruptedException {
		Thread.sleep(2000);
		driver.close();
	}
}
